import React, {Component} from "react";
import "./Header.css";



export default class Header1 extends Component{
    constructor(props){
        super(props);
        this.state={
            

        }
    }
  
    render(){
        return(
            <header className="Header">
                
                <div className="logo">
                
                    <img src="https://www.achieversit.com/assets/images/logo-white.png" alt="logo"/>
                   

                </div>
                <nav className="navbar">
                 <ul>
                       <li><a href="All Courses">All Courses</a></li>
                       <li><a href="Corporate Training">Corporate Training</a></li>
                       <li><a href="Placements">Placements</a></li>
                       <li><a href="Internships">Internships</a></li>
                       <li><a href="Review">Review</a></li>
                       <li><a href="Blogs">Blogs</a></li>
                       
                       

                      
                    </ul>
                    </nav>
                </header>
        )
    }
}